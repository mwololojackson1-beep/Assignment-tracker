package com.example.assignmenttracker.service;

import com.example.assignmenttracker.model.Assignment;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class AssignmentService {

    private final Map<Long, Assignment> store = new HashMap<>();
    private long idCounter = 1;

    public List<Assignment> getAll() {
        return new ArrayList<>(store.values());
    }

    public Assignment create(Assignment a) {
        a.setId(idCounter++);
        store.put(a.getId(), a);
        return a;
    }

    public Assignment update(Long id, Assignment a) {
        if (!store.containsKey(id)) return null;
        a.setId(id);
        store.put(id, a);
        return a;
    }

    public void delete(Long id) {
        store.remove(id);
    }
}
